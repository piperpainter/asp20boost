library(testthat)
library(asp20boost)

test_check("asp20boost")
